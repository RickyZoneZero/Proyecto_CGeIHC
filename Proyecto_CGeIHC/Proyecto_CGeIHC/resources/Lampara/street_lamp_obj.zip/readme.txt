﻿Low poly street lamp model, built with Maya 7, clean topology, no N-gons and triangles, quads only.
UV mapped and fully textured, unwrapping done with overlapping.
Maya 7 (.ma, .mb), OBJ (.obj with .mtl), 3ds Max 2009 (.max) and Autodesk FBX (.fbx) format included. FBX and OBJ are directly exported from Maya.
Polygons: 36 
Vertices: 40
Model is mapped on single 256×256 pixels texture map. Two formats included in street_lamp_textures.zip file: .tiff with LZW compression and .jpg. 




